<x-app-layout>
<div class="min-h-screen">
    <div class="p-5 sm:p-7.5 lg:p-9">
        <div class="mb-6">
            <h1 class="text-2xl font-bold text-gray-900 dark:text-white sm:text-3xl">Manajemen Jadwal Piket Mingguan</h1>
            <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">Kelola jadwal piket tim IT untuk setiap minggu</p>
        </div>

        @if (session('success'))
            <div class="mb-4 rounded-lg border border-green-400 bg-green-100 p-4 text-green-700 dark:border-green-500/30 dark:bg-green-500/15 dark:text-green-400">
                {{ session('success') }}
            </div>
        @endif
        @if (session('error'))
            <div class="mb-4 rounded-lg border border-amber-400 bg-amber-100 p-4 text-amber-800 dark:border-amber-500/30 dark:bg-amber-500/15 dark:text-amber-300">
                {{ session('error') }}
            </div>
        @endif

        @if (count($schedules) === 0)
            <div class="mb-4 rounded-lg border border-yellow-400 bg-yellow-100 p-4 text-yellow-700 dark:border-yellow-500/30 dark:bg-yellow-500/15 dark:text-yellow-400">
                <p class="font-semibold">Belum ada jadwal piket.</p>
                <p class="text-sm mt-1">Mulai dengan menambahkan jadwal piket baru menggunakan tombol "+ Tambah Jadwal".</p>
            </div>
        @endif

        @php
            $calendarEvents = collect($schedules)->map(function ($schedule) {
                $start = \Carbon\Carbon::parse($schedule->week_start_date);
                $end = $schedule->week_end_date
                    ? \Carbon\Carbon::parse($schedule->week_end_date)
                    : $start->copy()->addDays(6);
                $isPast = $schedule->hasPassed();
                return [
                    'title' => "Piket: {$start->format('d/m')} - {$end->format('d/m')}",
                    'start' => $start->toDateString(),
                    'end' => $end->copy()->addDay()->toDateString(), // FullCalendar end is exclusive
                    'url' => $isPast ? null : route('piket.edit', $schedule),
                    'allDay' => true,
                    'backgroundColor' => $isPast ? '#94a3b8' : '#8b5cf6',
                    'borderColor' => $isPast ? '#94a3b8' : '#8b5cf6',
                    'textColor' => '#ffffff',
                    'extendedProps' => [
                        'id' => $schedule->id,
                        'technician_1' => $schedule->technician_1,
                        'technician_2' => $schedule->technician_2,
                        'technician_3' => $schedule->technician_3,
                        'start_date' => $start->format('d/m/Y'),
                        'end_date' => $end->format('d/m/Y'),
                    ],
                ];
            })->toArray();

            $currentSchedule = collect($schedules)->first(function ($schedule) {
                $start = \Carbon\Carbon::parse($schedule->week_start_date);
                $end = $schedule->week_end_date
                    ? \Carbon\Carbon::parse($schedule->week_end_date)
                    : $start->copy()->addDays(6);
                return now()->between($start->startOfDay(), $end->endOfDay());
            });
        @endphp

        <div class="grid gap-3 md:grid-cols-2 mb-5">
            <div class="rounded-2xl border border-gray-200 bg-white p-4 shadow-sm dark:border-gray-700 dark:bg-dark-800">
                <div class="flex items-center justify-between gap-3">
                    <div>
                        <p class="text-xs uppercase tracking-[0.25em] text-gray-500 dark:text-gray-400">Total Jadwal</p>
                        <p class="mt-2 text-2xl font-semibold text-gray-900 dark:text-white">{{ $schedules->count() }}</p>
                    </div>
                    <span class="inline-flex items-center rounded-full bg-brand-50 px-2.5 py-1 text-xs font-semibold text-brand-700">{{ $schedules->count() }}</span>
                </div>
                <p class="mt-3 text-xs text-gray-500 dark:text-gray-400">Jumlah jadwal piket tersimpan.</p>
            </div>
            <div class="rounded-2xl border border-gray-200 bg-white p-4 shadow-sm dark:border-gray-700 dark:bg-dark-800">
                <p class="text-xs uppercase tracking-[0.25em] text-gray-500 dark:text-gray-400">Minggu Aktif</p>
                @if ($currentSchedule)
                    @php
                        $currentStart = \Carbon\Carbon::parse($currentSchedule->week_start_date);
                        $currentEnd = $currentSchedule->week_end_date
                            ? \Carbon\Carbon::parse($currentSchedule->week_end_date)
                            : $currentStart->copy()->addDays(6);
                    @endphp
                    <p class="mt-2 text-lg font-semibold text-gray-900 dark:text-white">{{ $currentStart->format('d M') }} — {{ $currentEnd->format('d M Y') }}</p>
                    <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">{{ $currentSchedule->technician_1 }}, {{ $currentSchedule->technician_2 }}, {{ $currentSchedule->technician_3 }}</p>
                @else
                    <p class="mt-2 text-lg font-semibold text-gray-900 dark:text-white">Tidak aktif</p>
                    <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">Tambahkan jadwal minggu ini.</p>
                @endif
            </div>
        </div>

        <div class="rounded-3xl border border-gray-200 bg-white p-6 shadow-sm dark:border-gray-700 dark:bg-dark-800">
            <div class="mb-6 flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
                <div>
                    <p class="text-sm uppercase tracking-[0.2em] text-gray-500 dark:text-gray-400">Kalender Piket</p>
                    <h2 class="mt-1 text-2xl font-semibold text-gray-900 dark:text-white">Jadwal Mingguan</h2>
                </div>
                <div class="flex flex-wrap items-center gap-3">
                    <span class="inline-flex items-center rounded-full bg-gray-100 px-3 py-1 text-sm font-medium text-gray-600 dark:bg-gray-800 dark:text-gray-300">
                        <span class="h-2.5 w-2.5 rounded-full bg-brand-500"></span>
                        {{ $schedules->count() }} jadwal tersedia
                    </span>
                    <a href="{{ route('piket.create') }}" class="inline-flex items-center rounded-full bg-brand-600 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-brand-700">+ Tambah Jadwal</a>
                </div>
            </div>

            <div class="min-h-[580px] w-full overflow-hidden rounded-3xl border border-gray-100 bg-white shadow-sm dark:border-gray-800 dark:bg-dark-900" id="piketCalendar"></div>
        </div>

        <div class="mt-6 rounded-3xl border border-gray-200 bg-white p-6 shadow-sm dark:border-gray-700 dark:bg-dark-800">
            <div class="mb-5 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <p class="text-sm uppercase tracking-[0.2em] text-gray-500 dark:text-gray-400">Daftar Jadwal Piket</p>
                    <h2 class="mt-1 text-2xl font-semibold text-gray-900 dark:text-white">Data Mingguan</h2>
                </div>
                <span class="inline-flex items-center rounded-full bg-brand-50 px-3 py-1 text-sm font-semibold text-brand-700">{{ $schedules->count() }} jadwal</span>
            </div>

            <div class="mb-5 flex flex-wrap items-center justify-end gap-2">
                <form method="GET" class="flex items-center gap-2">
                    <label for="rangeSelect" class="text-sm text-gray-500 dark:text-gray-400">Tampilkan</label>
                    <select id="rangeSelect" name="range" onchange="this.form.submit()" class="rounded-lg border border-gray-300 bg-white px-3 py-1.5 text-sm text-gray-700 focus:border-brand-500 focus:ring-brand-500 dark:border-gray-700 dark:bg-dark-900 dark:text-gray-200">
                        <option value="1" @selected($range === '1')>Per bulan</option>
                        <option value="2" @selected($range === '2')>Per 2 bulan</option>
                        <option value="3" @selected($range === '3')>Per 3 bulan</option>
                        <option value="all" @selected($range === 'all')>Semua</option>
                    </select>
                    <noscript><button type="submit" class="rounded-lg bg-brand-600 px-3 py-1.5 text-sm font-semibold text-white">Terapkan</button></noscript>
                </form>
            </div>

            <div class="overflow-x-auto rounded-3xl border border-gray-100 bg-white shadow-sm dark:border-gray-800 dark:bg-dark-900">
                <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                    <thead class="bg-gray-50 dark:bg-gray-900">
                        <tr>
                            <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-[0.18em] text-gray-500 dark:text-gray-400">Periode</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-[0.18em] text-gray-500 dark:text-gray-400">Petugas 1</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-[0.18em] text-gray-500 dark:text-gray-400">Petugas 2</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-[0.18em] text-gray-500 dark:text-gray-400">Petugas 3</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-[0.18em] text-gray-500 dark:text-gray-400">Status</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-[0.18em] text-gray-500 dark:text-gray-400">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100 bg-white dark:divide-gray-800 dark:bg-dark-900">
                        @forelse ($scheduleList as $schedule)
                            @php
                                $start = \Carbon\Carbon::parse($schedule->week_start_date);
                                $end = $schedule->week_end_date
                                    ? \Carbon\Carbon::parse($schedule->week_end_date)
                                    : $start->copy()->addDays(6);
                                $isCurrent = now()->between($start->startOfDay(), $end->endOfDay());
                                $isPast = $schedule->hasPassed();
                            @endphp
                            <tr class="hover:bg-gray-50 dark:hover:bg-gray-900 {{ $isCurrent ? 'bg-brand-50 dark:bg-brand-500/10' : '' }}">
                                <td class="px-4 py-4 align-top">
                                    <div class="text-sm font-semibold text-gray-900 dark:text-white">{{ $start->format('d M') }} — {{ $end->format('d M') }}</div>
                                    <div class="mt-1 text-xs text-gray-500 dark:text-gray-400">{{ $start->format('d M Y') }} sampai {{ $end->format('d M Y') }}</div>
                                </td>
                                <td class="px-4 py-4 align-top">
                                    <div class="rounded-2xl bg-gray-50 px-3 py-2 text-sm font-medium text-gray-700 dark:bg-gray-900 dark:text-gray-200">{{ $schedule->technician_1 }}</div>
                                </td>
                                <td class="px-4 py-4 align-top">
                                    <div class="rounded-2xl bg-gray-50 px-3 py-2 text-sm font-medium text-gray-700 dark:bg-gray-900 dark:text-gray-200">{{ $schedule->technician_2 }}</div>
                                </td>
                                <td class="px-4 py-4 align-top">
                                    <div class="rounded-2xl bg-gray-50 px-3 py-2 text-sm font-medium text-gray-700 dark:bg-gray-900 dark:text-gray-200">{{ $schedule->technician_3 }}</div>
                                </td>
                                <td class="px-4 py-4 align-top">
                                    @if ($isCurrent)
                                        <span class="inline-flex items-center rounded-full bg-brand-100 px-3 py-1 text-xs font-semibold text-brand-700">Minggu ini</span>
                                    @elseif ($isPast)
                                        <span class="inline-flex items-center rounded-full bg-gray-100 px-3 py-1 text-xs font-semibold text-gray-500 dark:bg-gray-800 dark:text-gray-400">Terlewat</span>
                                    @else
                                        <span class="text-sm text-gray-500 dark:text-gray-400">Terjadwal</span>
                                    @endif
                                </td>
                                <td class="px-4 py-4 align-top">
                                    <div class="flex flex-wrap gap-2">
                                        @if ($isPast)
                                            <span class="inline-flex items-center rounded-lg bg-gray-100 px-3 py-1.5 text-xs font-semibold text-gray-500 dark:bg-gray-800 dark:text-gray-400" title="Jadwal yang sudah terlewat tidak dapat diedit">Terkunci</span>
                                        @else
                                            <a href="{{ route('piket.edit', $schedule) }}" class="inline-flex items-center rounded-lg border border-gray-300 bg-white px-3 py-1.5 text-xs font-semibold text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:bg-dark-800 dark:text-gray-200 dark:hover:bg-gray-900">Edit</a>
                                        @endif
                                        <form method="POST" action="{{ route('piket.destroy', $schedule) }}" onsubmit="return confirm('Hapus jadwal piket ini? Tindakan ini tidak dapat dibatalkan.')">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="inline-flex items-center rounded-lg bg-red-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-red-700">Hapus</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="px-4 py-8 text-center text-sm text-gray-500 dark:text-gray-400">Tidak ada jadwal piket pada rentang ini.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            @if ($scheduleList instanceof \Illuminate\Contracts\Pagination\Paginator)
                <div class="mt-4">
                    <x-pagination :paginator="$scheduleList" />
                </div>
            @endif
        </div>

        <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css" rel="stylesheet">
        <style>
            #piketCalendar { min-height: 580px; }
            #piketCalendar .fc { min-height: 100%; }
            #piketCalendar .fc .fc-toolbar-title { font-size: 1rem; font-weight: 600; }
            #piketCalendar .fc .fc-daygrid-day-top { padding: 0.55rem 0.65rem; }
            #piketCalendar .fc .fc-daygrid-event { padding: 0.4rem 0.45rem; font-size: 0.75rem; border-radius: 0.55rem; }
            #piketCalendar .fc .fc-daygrid-more-link { font-size: 0.75rem; }
            #piketCalendar .fc .fc-event-title { white-space: normal; line-height: 1.15; }
            #piketCalendar .fc .fc-event-crew { color: rgba(255,255,255,0.85); font-size: 0.65rem; line-height: 1.15; }
        </style>
        <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                const calendarEl = document.getElementById('piketCalendar');
                if (!calendarEl) return;

                let tooltipEl = null;

                const removeTooltip = function() {
                    if (tooltipEl) {
                        document.body.removeChild(tooltipEl);
                        tooltipEl = null;
                    }
                };

                const calendar = new FullCalendar.Calendar(calendarEl, {
                    initialView: 'dayGridMonth',
                    headerToolbar: {
                        left: 'prev,next today',
                        center: 'title',
                        right: 'dayGridMonth,timeGridWeek,timeGridDay'
                    },
                    height: 'auto',
                    contentHeight: 'auto',
                    aspectRatio: 1.35,
                    events: @json($calendarEvents),
                    eventDisplay: 'block',
                    dayMaxEventRows: 2,
                    dayMaxEvents: true,
                    eventTimeFormat: { hour: '2-digit', minute: '2-digit', meridiem: false },
                    eventContent: function(arg) {
                        const props = arg.event.extendedProps;
                        const names = [props.technician_1, props.technician_2, props.technician_3].filter(Boolean).join(', ');
                        const title = arg.event.title;

                        return {
                            html: `
                                <div class="fc-event-title">${title}</div>
                                <div class="fc-event-crew text-[0.68rem] mt-1">${names}</div>
                            `
                        };
                    },
                    eventDidMount: function(info) {
                        info.el.style.padding = '0.45rem';
                        info.el.style.borderRadius = '0.85rem';
                        info.el.style.cursor = info.event.url ? 'pointer' : 'default';
                    },
                    eventClick: function(info) {
                        if (info.event.url) {
                            info.jsEvent.preventDefault();
                            window.location.href = info.event.url;
                        }
                    },
                    eventMouseEnter: function(info) {
                        removeTooltip();
                        const props = info.event.extendedProps;
                        const tooltip = `
                            <div class="bg-gray-900 text-white p-3 rounded-lg shadow-lg max-w-[18rem]">
                                <div class="font-semibold mb-2">Jadwal Piket Mingguan</div>
                                <div class="text-xs sm:text-sm space-y-1">
                                    <div><strong>Mulai:</strong> ${props.start_date}</div>
                                    <div><strong>Selesai:</strong> ${props.end_date}</div>
                                    <div class="border-t border-gray-700 mt-2 pt-2">
                                        <div><strong>Petugas 1:</strong> ${props.technician_1}</div>
                                        <div><strong>Petugas 2:</strong> ${props.technician_2}</div>
                                        <div><strong>Petugas 3:</strong> ${props.technician_3}</div>
                                    </div>
                                </div>
                            </div>
                        `;

                        tooltipEl = document.createElement('div');
                        tooltipEl.innerHTML = tooltip;
                        tooltipEl.style.position = 'absolute';
                        tooltipEl.style.zIndex = '9999';
                        tooltipEl.style.pointerEvents = 'none';
                        document.body.appendChild(tooltipEl);

                        const rect = info.el.getBoundingClientRect();
                        tooltipEl.style.left = `${rect.left}px`;
                        tooltipEl.style.top = `${rect.top - tooltipEl.offsetHeight - 10}px`;
                    },
                    eventMouseLeave: function() {
                        removeTooltip();
                    }
                });

                calendar.render();
            });
        </script>
    </div>
</div>
</x-app-layout>
