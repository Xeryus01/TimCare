<x-app-layout>
<div class="min-h-screen">
    <div class="p-5 sm:p-7.5 lg:p-9">
        <div class="mb-6 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
                <h1 class="text-2xl font-bold text-gray-900 dark:text-white sm:text-3xl">Pengajuan Zoom</h1>
                <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">User mengajukan kebutuhan Zoom, lalu teknisi atau admin melakukan follow up dan menambahkan link meeting.</p>
            </div>
            <div class="flex flex-wrap gap-2">
                <a href="{{ url()->to(route('reservations.create')) }}" class="rounded-lg bg-brand-600 px-4 py-2 font-medium text-white hover:bg-brand-700">Ajukan Zoom</a>
                <a href="{{ url()->to(route('exports.reservations', request()->query())) }}" class="rounded-lg border border-gray-300 px-4 py-2 font-medium text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-white/5">Ekspor CSV</a>
            </div>
        </div>

        <div class="mb-4 rounded-3xl border border-gray-200 bg-white p-3 dark:border-gray-700 dark:bg-dark-800">
            <h2 class="text-xs font-semibold uppercase tracking-wide text-gray-600 dark:text-gray-400">Alur Pengajuan Zoom</h2>
            <div class="mt-3 grid gap-2 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
                <div class="rounded-2xl border border-gray-100 bg-gray-50 p-2 dark:border-white/10 dark:bg-white/5">
                    <div class="flex items-center gap-2">
                        <span class="text-xs font-semibold text-sky-600">1.</span>
                        <p class="text-xs font-semibold text-gray-900 dark:text-white">Ajukan</p>
                    </div>
                    <p class="mt-1 text-[11px] leading-4 text-gray-600 dark:text-gray-400">Isi kebutuhan Zoom dan upload nota dinas.</p>
                </div>
                <div class="rounded-2xl border border-gray-100 bg-gray-50 p-2 dark:border-white/10 dark:bg-white/5">
                    <div class="flex items-center gap-2">
                        <span class="text-xs font-semibold text-sky-600">2.</span>
                        <p class="text-xs font-semibold text-gray-900 dark:text-white">Assign</p>
                    </div>
                    <p class="mt-1 text-[11px] leading-4 text-gray-600 dark:text-gray-400">Admin/teknisi menindaklanjuti permohonan.</p>
                </div>
                <div class="rounded-2xl border border-gray-100 bg-gray-50 p-2 dark:border-white/10 dark:bg-white/5">
                    <div class="flex items-center gap-2">
                        <span class="text-xs font-semibold text-sky-600">3.</span>
                        <p class="text-xs font-semibold text-gray-900 dark:text-white">Cek ID Meeting</p>
                    </div>
                    <p class="mt-1 text-[11px] leading-4 text-gray-600 dark:text-gray-400">Jika ruang id meeting zoom masih tersedia, lanjutkan. Jika tidak, konfirmasi.</p>
                </div>
                <div class="rounded-2xl border border-gray-100 bg-gray-50 p-2 dark:border-white/10 dark:bg-white/5">
                    <div class="flex items-center gap-2">
                        <span class="text-xs font-semibold text-sky-600">4.</span>
                        <p class="text-xs font-semibold text-gray-900 dark:text-white">Selesai</p>
                    </div>
                    <p class="mt-1 text-[11px] leading-4 text-gray-600 dark:text-gray-400">Link Zoom ditambahkan jika disetujui.</p>
                </div>
            </div>
        </div>

        <form method="GET" class="mb-4 flex flex-wrap gap-3 rounded-xl border border-gray-200 bg-white p-4 dark:border-gray-700 dark:bg-dark-800">
            <select name="status" class="rounded-lg border-gray-300 px-3 py-2 dark:bg-dark-800 dark:text-white">
                <option value="">Semua status</option>
                @foreach(\App\Models\Reservation::statusLabels() as $value => $label)
                    <option value="{{ $value }}" {{ request('status') === $value ? 'selected' : '' }}>{{ $label }}</option>
                @endforeach
            </select>
            <select name="requester_id" class="rounded-lg border-gray-300 px-3 py-2 dark:bg-dark-800 dark:text-white">
                <option value="">Semua pemohon</option>
                @foreach($requesters as $r)
                    <option value="{{ $r->id }}" {{ (string) request('requester_id') === (string) $r->id ? 'selected' : '' }}>{{ $r->name }}</option>
                @endforeach
            </select>
            <select name="approver_id" class="rounded-lg border-gray-300 px-3 py-2 dark:bg-dark-800 dark:text-white">
                <option value="">Semua petugas</option>
                @foreach($approvers as $a)
                    <option value="{{ $a->id }}" {{ (string) request('approver_id') === (string) $a->id ? 'selected' : '' }}>{{ $a->name }}</option>
                @endforeach
            </select>
            <button type="submit" class="rounded-lg bg-brand-600 px-4 py-2 text-white">Terapkan</button>
        </form>

        @if(auth()->user()->hasRole('Admin'))
            <form id="reservation-bulk-assign" method="POST" action="{{ route('reservations.bulk-assign') }}" class="mb-4 flex flex-col gap-3 rounded-xl border border-blue-100 bg-blue-50/70 p-4 dark:border-blue-500/20 dark:bg-blue-500/5 sm:flex-row sm:items-end sm:justify-between">
                @csrf
                <div class="flex flex-wrap items-end gap-3">
                    <div>
                        <label for="reservation-bulk-action" class="mb-1 block text-sm font-semibold text-gray-800 dark:text-gray-100">Aksi massal</label>
                        <select id="reservation-bulk-action" name="bulk_action" required class="min-w-48 rounded-lg border-gray-300 px-3 py-2 dark:border-gray-600 dark:bg-dark-800 dark:text-white">
                            <option value="assign" {{ old('bulk_action', 'assign') === 'assign' ? 'selected' : '' }}>Tugaskan teknisi</option>
                            <option value="status" {{ old('bulk_action') === 'status' ? 'selected' : '' }}>Ubah status</option>
                        </select>
                    </div>
                    <div id="reservation-bulk-approver-fields">
                        <label for="reservation-bulk-approver" class="mb-1 block text-sm font-medium text-gray-700 dark:text-gray-300">Teknisi</label>
                        <select id="reservation-bulk-approver" name="approver_id" class="min-w-60 rounded-lg border-gray-300 px-3 py-2 dark:border-gray-600 dark:bg-dark-800 dark:text-white">
                            <option value="">Pilih teknisi</option>
                            @foreach($technicians as $technician)
                                <option value="{{ $technician->id }}" {{ (string) old('approver_id') === (string) $technician->id ? 'selected' : '' }}>{{ $technician->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div id="reservation-bulk-status-fields" class="hidden">
                        <label for="reservation-bulk-status" class="mb-1 block text-sm font-medium text-gray-700 dark:text-gray-300">Status baru</label>
                        <select id="reservation-bulk-status" name="status" class="min-w-60 rounded-lg border-gray-300 px-3 py-2 dark:border-gray-600 dark:bg-dark-800 dark:text-white">
                            <option value="">Pilih status</option>
                            @foreach(\App\Models\Reservation::statusLabels() as $value => $label)
                                @if($value !== \App\Models\Reservation::STATUS_PENDING)
                                    <option value="{{ $value }}" {{ old('status') === $value ? 'selected' : '' }}>{{ $label }}</option>
                                @endif
                            @endforeach
                        </select>
                    </div>
                    <p class="text-xs text-gray-600 dark:text-gray-400">Pilih pengajuan aktif pada halaman ini, maksimal 50 per proses.</p>
                </div>
                <div class="flex items-center gap-3">
                    <span id="reservation-bulk-count" class="text-sm text-gray-600 dark:text-gray-400">0 pengajuan dipilih</span>
                    <button id="reservation-bulk-submit" type="submit" class="rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700">Tugaskan</button>
                </div>
                @if($errors->any())
                    <div class="basis-full text-sm text-red-600 dark:text-red-400">
                        @foreach($errors->all() as $error)
                            <p>{{ $error }}</p>
                        @endforeach
                    </div>
                @endif
            </form>
        @endif

        @php
            $sort = request('sort');
            $direction = request('direction', 'asc') === 'desc' ? 'desc' : 'asc';
            $baseQuery = request()->except('page');
        @endphp

        <div class="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-gray-700 dark:bg-dark-800">
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="border-b border-gray-200 bg-gray-50 dark:border-gray-700 dark:bg-white/5">
                        <tr>
                            @if(auth()->user()->hasRole('Admin'))
                                <th class="px-4 py-3.5 text-left">
                                    <input id="reservation-select-page" type="checkbox" aria-label="Pilih semua pengajuan aktif pada halaman ini" class="rounded border-gray-300 text-brand-600 focus:ring-brand-500">
                                </th>
                            @endif
                            <th class="px-5 py-3.5 text-left text-xs font-semibold uppercase text-gray-500 dark:text-gray-400 sm:px-6">
                                @php $nextDir = ($sort === 'code' && $direction === 'asc') ? 'desc' : 'asc'; @endphp
                                <a href="{{ url()->current() . '?' . http_build_query(array_merge($baseQuery, ['sort' => 'code', 'direction' => $nextDir])) }}" class="inline-flex items-center gap-1">
                                    Kode
                                    @if($sort === 'code')
                                        <span>{{ $direction === 'asc' ? '▲' : '▼' }}</span>
                                    @endif
                                </a>
                            </th>
                            <th class="px-5 py-3.5 text-left text-xs font-semibold uppercase text-gray-500 dark:text-gray-400 sm:px-6">
                                @php $nextDir = ($sort === 'room_name' && $direction === 'asc') ? 'desc' : 'asc'; @endphp
                                <a href="{{ url()->current() . '?' . http_build_query(array_merge($baseQuery, ['sort' => 'room_name', 'direction' => $nextDir])) }}" class="inline-flex items-center gap-1">
                                    Kegiatan / Ruang
                                    @if($sort === 'room_name')
                                        <span>{{ $direction === 'asc' ? '▲' : '▼' }}</span>
                                    @endif
                                </a>
                            </th>
                            <th class="px-5 py-3.5 text-left text-xs font-semibold uppercase text-gray-500 dark:text-gray-400 sm:px-6">
                                @php $nextDir = ($sort === 'start_time' && $direction === 'asc') ? 'desc' : 'asc'; @endphp
                                <a href="{{ url()->current() . '?' . http_build_query(array_merge($baseQuery, ['sort' => 'start_time', 'direction' => $nextDir])) }}" class="inline-flex items-center gap-1">
                                    Jadwal
                                    @if($sort === 'start_time')
                                        <span>{{ $direction === 'asc' ? '▲' : '▼' }}</span>
                                    @endif
                                </a>
                            </th>
                            <th class="px-5 py-3.5 text-left text-xs font-semibold uppercase text-gray-500 dark:text-gray-400 sm:px-6">
                                @php $nextDir = ($sort === 'requester' && $direction === 'asc') ? 'desc' : 'asc'; @endphp
                                <a href="{{ url()->current() . '?' . http_build_query(array_merge($baseQuery, ['sort' => 'requester', 'direction' => $nextDir])) }}" class="inline-flex items-center gap-1">
                                    Pemohon
                                    @if($sort === 'requester')
                                        <span>{{ $direction === 'asc' ? '▲' : '▼' }}</span>
                                    @endif
                                </a>
                            </th>
                            <th class="px-5 py-3.5 text-left text-xs font-semibold uppercase text-gray-500 dark:text-gray-400 sm:px-6">
                                @php $nextDir = ($sort === 'status' && $direction === 'asc') ? 'desc' : 'asc'; @endphp
                                <a href="{{ url()->current() . '?' . http_build_query(array_merge($baseQuery, ['sort' => 'status', 'direction' => $nextDir])) }}" class="inline-flex items-center gap-1">
                                    Status
                                    @if($sort === 'status')
                                        <span>{{ $direction === 'asc' ? '▲' : '▼' }}</span>
                                    @endif
                                </a>
                            </th>
                            <th class="px-5 py-3.5 text-left text-xs font-semibold uppercase text-gray-500 dark:text-gray-400 sm:px-6">Link Zoom</th>
                            <th class="px-5 py-3.5 text-left text-xs font-semibold uppercase text-gray-500 dark:text-gray-400 sm:px-6">
                                @php $nextDir = ($sort === 'approver' && $direction === 'asc') ? 'desc' : 'asc'; @endphp
                                <a href="{{ url()->current() . '?' . http_build_query(array_merge($baseQuery, ['sort' => 'approver', 'direction' => $nextDir])) }}" class="inline-flex items-center gap-1">
                                    Petugas
                                    @if($sort === 'approver')
                                        <span>{{ $direction === 'asc' ? '▲' : '▼' }}</span>
                                    @endif
                                </a>
                            </th>
                            <th class="px-5 py-3.5 text-right text-xs font-semibold uppercase text-gray-500 dark:text-gray-400 sm:px-6">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                        @forelse($reservations as $r)
                            <tr class="hover:bg-gray-50 dark:hover:bg-white/5">
                                @if(auth()->user()->hasRole('Admin'))
                                    @php
                                        $reservationIsClosed = in_array($r->status, [
                                            \App\Models\Reservation::STATUS_COMPLETED,
                                            \App\Models\Reservation::STATUS_REJECTED,
                                            \App\Models\Reservation::STATUS_CANCELLED,
                                        ], true);
                                    @endphp
                                    <td class="px-4 py-4">
                                        <input type="checkbox" name="reservation_ids[]" value="{{ $r->id }}" form="reservation-bulk-assign" {{ $reservationIsClosed ? 'disabled' : '' }} {{ in_array($r->id, old('reservation_ids', [])) ? 'checked' : '' }} aria-label="Pilih pengajuan Zoom {{ $r->code }}" class="reservation-select-row rounded border-gray-300 text-brand-600 focus:ring-brand-500 disabled:cursor-not-allowed disabled:opacity-40">
                                    </td>
                                @endif
                                <td class="px-5 py-4 sm:px-6 text-sm font-semibold text-gray-900 dark:text-white">{{ $r->code }}</td>
                                <td class="px-5 py-4 sm:px-6">
                                    <p class="text-sm font-semibold text-gray-900 dark:text-white">{{ $r->room_name }}</p>
                                    <p class="text-xs text-gray-500 dark:text-gray-400">{{ \Illuminate\Support\Str::limit($r->purpose, 45) }}</p>
                                </td>
                                <td class="px-5 py-4 sm:px-6 text-sm text-gray-700 dark:text-gray-300">
                                    {{ $r->start_time->format('d/m/Y H:i') }}<br>
                                    <span class="text-xs text-gray-500 dark:text-gray-400">s/d {{ $r->end_time->format('d/m/Y H:i') }}</span>
                                </td>
                                <td class="px-5 py-4 sm:px-6 text-sm text-gray-700 dark:text-gray-300">{{ optional($r->requester)->name ?? '-' }}</td>
                                <td class="px-5 py-4 sm:px-6">
                                    <span class="inline-flex rounded-full px-2.5 py-0.5 text-xs font-medium {{ $r->status_badge_classes }}">
                                        {{ $r->status_label }}
                                    </span>
                                </td>
                                <td class="px-5 py-4 sm:px-6 text-sm text-gray-700 dark:text-gray-300">
                                    @if($r->zoom_link)
                                        <a href="{{ $r->zoom_link }}" target="_blank" class="text-brand-600 hover:underline">Buka link</a>
                                    @else
                                        <span class="text-gray-400">Belum ada</span>
                                    @endif
                                </td>
                                <td class="px-5 py-4 sm:px-6 text-sm text-gray-700 dark:text-gray-300">{{ optional($r->approver)->name ?? '-' }}</td>
                                <td class="px-5 py-4 text-right sm:px-6">
                                    <div class="flex items-center justify-end gap-2">
                                        <a href="{{ url()->to(route('reservations.show', $r)) }}" class="inline-flex items-center gap-1.5 rounded-lg border border-blue-200 bg-blue-50 px-3 py-1.5 text-xs font-semibold text-blue-700 shadow-sm hover:bg-blue-100 dark:border-blue-500/20 dark:bg-blue-500/10 dark:text-blue-400 dark:hover:bg-blue-500/20">
                                            <svg class="size-3.5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                                            Detail
                                        </a>
                                        @if(auth()->user()->hasRole('Admin'))
                                            <form method="POST" action="{{ route('reservations.destroy', $r) }}" class="inline" onsubmit="return confirm('Hapus pengajuan Zoom {{ $r->code }}? Tindakan ini tidak dapat dibatalkan.')">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="inline-flex items-center gap-1.5 rounded-lg border border-red-200 bg-red-50 px-3 py-1.5 text-xs font-semibold text-red-700 shadow-sm hover:bg-red-100 dark:border-red-500/20 dark:bg-red-500/10 dark:text-red-400 dark:hover:bg-red-500/20">
                                                    <svg class="size-3.5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                                                    Hapus
                                                </button>
                                            </form>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="{{ auth()->user()->hasRole('Admin') ? 9 : 8 }}" class="px-5 py-8 text-center text-sm text-gray-500 dark:text-gray-400 sm:px-6">Belum ada pengajuan Zoom.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            @if($reservations->hasPages())
                <x-pagination :paginator="$reservations" />
            @endif
        </div>
    </div>
</div>
@if(auth()->user()->hasRole('Admin'))
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const selectAll = document.getElementById('reservation-select-page');
            const rows = Array.from(document.querySelectorAll('.reservation-select-row:not(:disabled)'));
            const count = document.getElementById('reservation-bulk-count');
            const action = document.getElementById('reservation-bulk-action');
            const approverFields = document.getElementById('reservation-bulk-approver-fields');
            const approver = document.getElementById('reservation-bulk-approver');
            const statusFields = document.getElementById('reservation-bulk-status-fields');
            const status = document.getElementById('reservation-bulk-status');
            const submit = document.getElementById('reservation-bulk-submit');

            const updateAction = function () {
                const assigning = action.value === 'assign';
                approverFields.classList.toggle('hidden', !assigning);
                approver.required = assigning;
                approver.disabled = !assigning;
                statusFields.classList.toggle('hidden', assigning);
                status.required = !assigning;
                status.disabled = assigning;
                submit.textContent = assigning ? 'Tugaskan' : 'Ubah status';
            };

            const updateSelection = function () {
                const selected = rows.filter((checkbox) => checkbox.checked).length;
                count.textContent = `${selected} pengajuan dipilih`;
                selectAll.checked = rows.length > 0 && selected === rows.length;
                selectAll.indeterminate = selected > 0 && selected < rows.length;
            };

            selectAll.addEventListener('change', function () {
                rows.forEach((checkbox) => { checkbox.checked = selectAll.checked; });
                updateSelection();
            });
            action.addEventListener('change', updateAction);
            rows.forEach((checkbox) => checkbox.addEventListener('change', updateSelection));
            updateAction();
            updateSelection();
        });
    </script>
@endif
</x-app-layout>
